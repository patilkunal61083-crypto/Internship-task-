const express=require("express"),mongoose=require("mongoose"),cors=require("cors"),dotenv=require("dotenv");
dotenv.config();const app=express();app.use(cors());app.use(express.json());
const Task=mongoose.model("Task",new mongoose.Schema({title:{type:String,required:true},completed:{type:Boolean,default:false},createdAt:{type:Date,default:Date.now}}));
app.get("/api/tasks",async(req,res)=>res.json(await Task.find().sort({createdAt:-1})));
app.post("/api/tasks",async(req,res)=>{try{res.status(201).json(await Task.create({title:req.body.title}))}catch(e){res.status(400).json({message:e.message})}});
app.put("/api/tasks/:id",async(req,res)=>{try{res.json(await Task.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true}))}catch(e){res.status(400).json({message:e.message})}});
app.delete("/api/tasks/:id",async(req,res)=>{await Task.findByIdAndDelete(req.params.id);res.json({message:"Deleted"})});
mongoose.connect(process.env.MONGO_URI||"mongodb://127.0.0.1:27017/todo_app").then(()=>app.listen(process.env.PORT||5001,()=>console.log("Todo API: http://localhost:5001"))).catch(console.error);
