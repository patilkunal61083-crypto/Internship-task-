# Task 03 — To-Do Web App
## Backend
`cd backend` → `npm install` → copy `.env.example` to `.env` → `npm start`.

## Frontend
`cd frontend` → `npm install` → `npm run dev`.

The React app supports Add, Active/Completed filtering, completion toggle and Delete. MongoDB persists tasks through the REST API.
