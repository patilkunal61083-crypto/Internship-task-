import React,{useEffect,useState} from "react";import{createRoot}from"react-dom/client";import"./style.css";
const API="http://localhost:5001/api/tasks";
function App(){const[tasks,setTasks]=useState([]),[title,setTitle]=useState(""),[filter,setFilter]=useState("all");
const load=async()=>setTasks(await (await fetch(API)).json());useEffect(()=>{load()},[]);
const add=async e=>{e.preventDefault();if(!title.trim())return;await fetch(API,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({title})});setTitle("");load()};
const toggle=async t=>{await fetch(API+"/"+t._id,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({completed:!t.completed})});load()};
const remove=async id=>{await fetch(API+"/"+id,{method:"DELETE"});load()};
const shown=tasks.filter(t=>filter==="all"||filter==="active"&&!t.completed||filter==="completed"&&t.completed);
return <div className="app"><div className="box"><h1>To-Do App</h1><form onSubmit={add}><input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Add a new task"/><button>Add</button></form><div className="filters">{["all","active","completed"].map(x=><button className={filter===x?"active":""} onClick={()=>setFilter(x)}>{x}</button>)}</div><div>{shown.map(t=><div className={"task "+(t.completed?"done":"")} key={t._id}><input type="checkbox" checked={t.completed} onChange={()=>toggle(t)}/><span>{t.title}</span><button onClick={()=>remove(t._id)}>Delete</button></div>)}</div><p>{tasks.filter(t=>!t.completed).length} active task(s)</p></div></div>}
createRoot(document.getElementById("root")).render(<App/>);
