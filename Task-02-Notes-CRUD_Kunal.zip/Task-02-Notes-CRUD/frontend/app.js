const API="http://localhost:5000/api/notes";let editing=null;
const title=document.getElementById("title"),content=document.getElementById("content"),notes=document.getElementById("notes"),save=document.getElementById("save"),cancel=document.getElementById("cancel");
async function load(){const r=await fetch(API);const data=await r.json();notes.innerHTML=data.map(n=>`<article class="note"><h3>${escapeHtml(n.title)}</h3><p>${escapeHtml(n.content)}</p><small>${new Date(n.updatedAt).toLocaleString()}</small><div class="actions"><button class="edit" onclick="editNote('${n._id}','${encodeURIComponent(n.title)}','${encodeURIComponent(n.content)}')">Edit</button><button class="delete" onclick="deleteNote('${n._id}')">Delete</button></div></article>`).join("")}
save.onclick=async()=>{if(!title.value.trim()||!content.value.trim())return alert("Enter title and content");const method=editing?"PUT":"POST",url=editing?`${API}/${editing}`:API;await fetch(url,{method,headers:{"Content-Type":"application/json"},body:JSON.stringify({title:title.value,content:content.value})});reset();load()};
cancel.onclick=reset;
window.editNote=(id,t,c)=>{editing=id;title.value=decodeURIComponent(t);content.value=decodeURIComponent(c);save.textContent="Update Note";cancel.hidden=false;window.scrollTo({top:0,behavior:"smooth"})};
window.deleteNote=async id=>{if(confirm("Delete this note?")){await fetch(`${API}/${id}`,{method:"DELETE"});load()}};
function reset(){editing=null;title.value="";content.value="";save.textContent="Add Note";cancel.hidden=true}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
load();
