const express=require("express"), mongoose=require("mongoose"), cors=require("cors"), dotenv=require("dotenv");
dotenv.config();
const app=express(); app.use(cors()); app.use(express.json());
const Note=mongoose.model("Note",new mongoose.Schema({
  title:{type:String,required:true,trim:true},
  content:{type:String,required:true},
  createdAt:{type:Date,default:Date.now},
  updatedAt:{type:Date,default:Date.now}
}));
app.get("/api/notes",async(req,res)=>res.json(await Note.find().sort({updatedAt:-1})));
app.get("/api/notes/:id",async(req,res)=>{try{const n=await Note.findById(req.params.id); if(!n)return res.status(404).json({message:"Note not found"});res.json(n)}catch(e){res.status(400).json({message:"Invalid id"})}});
app.post("/api/notes",async(req,res)=>{try{const n=await Note.create({title:req.body.title,content:req.body.content});res.status(201).json(n)}catch(e){res.status(400).json({message:e.message})}});
app.put("/api/notes/:id",async(req,res)=>{try{const n=await Note.findByIdAndUpdate(req.params.id,{title:req.body.title,content:req.body.content,updatedAt:new Date()},{new:true,runValidators:true});if(!n)return res.status(404).json({message:"Note not found"});res.json(n)}catch(e){res.status(400).json({message:e.message})}});
app.delete("/api/notes/:id",async(req,res)=>{try{const n=await Note.findByIdAndDelete(req.params.id);if(!n)return res.status(404).json({message:"Note not found"});res.json({message:"Deleted"})}catch(e){res.status(400).json({message:"Invalid id"})}});
mongoose.connect(process.env.MONGO_URI||"mongodb://127.0.0.1:27017/notes_app").then(()=>app.listen(process.env.PORT||5000,()=>console.log("Notes API running on http://localhost:5000"))).catch(console.error);
