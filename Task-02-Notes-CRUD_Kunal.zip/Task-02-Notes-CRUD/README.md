# Task 02 — Notes CRUD
Requirements: Node.js and MongoDB (local MongoDB or MongoDB Atlas).

## Run
1. Open `backend` in terminal.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and change MONGO_URI if needed.
4. Run `npm start`.
5. Open `frontend/index.html` in a browser.

API: GET/POST `/api/notes`, PUT/DELETE `/api/notes/:id`.
