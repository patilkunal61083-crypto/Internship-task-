# Task 04 — Mini E-Commerce
## Backend
`cd backend` → `npm install` → copy `.env.example` to `.env` → `npm start`.
Then open `http://localhost:5002/api/seed` with a browser once to create demo products.

## Frontend
`cd frontend` → `npm install` → `npm run dev`.

Includes product listing/detail, cart, login/register, and demo checkout. No real payment is used.
